import json
import random

from . import config

ANTONYMS = {
    "black": "white", "white": "black", "red": "blue", "blue": "red",
    "green": "purple", "purple": "green", "yellow": "gray", "gray": "yellow",
    "long": "short", "short": "long", "round": "square", "square": "round",
    "thick": "thin", "thin": "thick", "curly": "straight", "straight": "curly",
}

REWRITE_PROMPT = """Rewrite this attribute description as a yes/no question about
the image. Output the question only.

Description: {description}"""

NEGATIVE_PROMPT = """Replace the attribute in this question with its opposite,
keeping the sentence structure. Output the question only.

Question: {question}"""


def rewrite(client, description):
    return client.chat([{"role": "user", "content": REWRITE_PROMPT.format(
        description=description)}])[0].strip()


def negate(client, question):
    return client.chat([{"role": "user", "content": NEGATIVE_PROMPT.format(
        question=question)}])[0].strip()


def swap_attribute(question):
    words = question.split()
    for i, word in enumerate(words):
        key = word.strip("?,.!").lower()
        if key in ANTONYMS:
            words[i] = words[i].replace(word.strip("?,.!"), ANTONYMS[key])
            break
    return " ".join(words)


def build_benchmark(client, samples, use_llm=True):
    rows = []
    for image, description in samples:
        positive = rewrite(client, description) if use_llm else f"Is the attribute {description}?"
        negative = negate(client, positive) if use_llm else swap_attribute(positive)
        rows.append({"image": image, "positive": positive, "negative": negative,
                     "answer_positive": "Yes", "answer_negative": "No"})
    return rows


def split(rows, ratio=None, seed=0):
    rows = list(rows)
    random.Random(seed).shuffle(rows)
    cut = int(len(rows) * (ratio or config.SPLIT))
    return rows[:cut], rows[cut:]


def save(rows, path):
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]
