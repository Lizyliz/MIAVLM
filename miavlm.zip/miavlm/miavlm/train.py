import torch
from torch.optim import Adam
from torch.optim.lr_scheduler import CosineAnnealingLR

from . import config


def train_step(model, batch, tokenizer):
    prompts = [tokenizer(q, return_tensors="pt", padding=True) for q in batch["question"]]
    input_ids = torch.cat([p.input_ids for p in prompts])
    labels = input_ids.clone()
    output = model(batch["views"], input_ids, labels)
    return output.loss


def train(model, loader, tokenizer, epochs=None):
    optimizer = Adam([p for p in model.parameters() if p.requires_grad], lr=config.LR)
    scheduler = CosineAnnealingLR(optimizer, T_max=(epochs or config.EPOCHS) * len(loader))
    model.train()
    for _ in range(epochs or config.EPOCHS):
        for batch in loader:
            loss = train_step(model, batch, tokenizer)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            scheduler.step()
    return model


def save(model, path):
    torch.save(model.map.state_dict(), path)


def load_map(model, path):
    model.map.load_state_dict(torch.load(path, map_location="cpu"))
    return model
