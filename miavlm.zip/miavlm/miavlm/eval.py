import re
import time

from . import config

YES = {"yes", "true", "correct"}
NO = {"no", "false", "incorrect"}


def normalise(text):
    return re.sub(r"[^a-z ]", "", text.strip().lower())


def answer(text):
    words = normalise(text).split()
    for word in words:
        if word in YES:
            return "Yes"
        if word in NO:
            return "No"
    return "Unknown"


def predict(model, tokenizer, views, question):
    inputs = tokenizer(question, return_tensors="pt")
    output = model.generate(
        views, inputs.input_ids,
        max_new_tokens=config.MAX_NEW_TOKENS,
        do_sample=config.TEMPERATURE > 0,
        temperature=config.TEMPERATURE or None,
    )
    return answer(tokenizer.decode(output[0], skip_special_tokens=True))


def evaluate(model, tokenizer, rows):
    positive = negative = 0
    for row in rows:
        positive += predict(model, tokenizer, row["views"], row["positive"]) == "Yes"
        negative += predict(model, tokenizer, row["views"], row["negative"]) == "No"
    pos_acc = positive / max(len(rows), 1)
    neg_acc = negative / max(len(rows), 1)
    return {"positive": pos_acc, "negative": neg_acc, "hooa": (pos_acc + neg_acc) / 2}


def order_sensitivity(model, tokenizer, row, repeats=5):
    import random

    predictions = []
    for _ in range(repeats):
        views = list(row["views"])
        random.shuffle(views)
        predictions.append(predict(model, tokenizer, views, row["positive"]))
    return len(set(predictions)) / repeats


def inference_time(model, tokenizer, row, repeats=10):
    start = time.time()
    for _ in range(repeats):
        predict(model, tokenizer, row["views"], row["positive"])
    return (time.time() - start) / repeats
