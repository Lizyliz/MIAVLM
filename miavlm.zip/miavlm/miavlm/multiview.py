import torch

from . import config


class MultiviewGenerator:
    """Wraps a single-image 3D generator and renders the requested cameras."""

    def __init__(self, generator, renderer):
        self.generator = generator
        self.renderer = renderer

    def cameras(self):
        cams = []
        for elevation in config.CAMERA_ELEVATIONS:
            for azimuth in config.CAMERA_AZIMUTHS:
                cams.append({"azimuth": azimuth, "elevation": elevation})
        cams.sort(key=lambda c: abs(c["azimuth"]) + abs(c["elevation"]))
        return cams[: config.NUM_VIEWS - 1]

    def __call__(self, image):
        mesh = self.generator(image)
        views = [image]
        views += [self.renderer(mesh, cam) for cam in self.cameras()]
        return views[: config.NUM_VIEWS]


def stack_views(views, transform):
    tensors = [transform(v) for v in views]
    return torch.stack(tensors, dim=1).squeeze(0)
