import math

import torch
import torch.nn as nn

from . import config


class VisualExtractor(nn.Module):
    def __init__(self, dim=config.DIM, prompts=config.SOFT_PROMPTS,
                 blocks=config.BLOCKS, heads=16):
        super().__init__()
        self.prompts = nn.Parameter(torch.randn(1, prompts, dim) * 0.02)
        self.blocks = nn.ModuleList([
            nn.TransformerDecoderLayer(dim, heads, batch_first=True, norm_first=True)
            for _ in range(blocks)
        ])
        self.norm = nn.LayerNorm(dim)

    def forward(self, embeddings):
        views, batch = embeddings.shape[:2]
        outputs = []
        for i in range(views):
            prompt = self.prompts.expand(batch, -1, -1)
            for block in self.blocks:
                prompt = block(prompt, embeddings[i])
            outputs.append(self.norm(prompt))
        return torch.stack(outputs)


class Decomposer(nn.Module):
    def __init__(self, dim=config.DIM, tokens=config.HEADS):
        super().__init__()
        self.tokens = tokens
        self.dim = dim
        self.mlp = nn.Sequential(nn.Linear(dim, dim), nn.GELU(),
                                 nn.Linear(dim, tokens * dim))

    def forward(self, cls):
        return self.mlp(cls).view(*cls.shape[:2], self.tokens, self.dim)


class MultiheadSampler(nn.Module):
    def __init__(self, dim=config.DIM):
        super().__init__()
        self.query = nn.Linear(dim, dim)

    def forward(self, tokens, embeddings):
        score = torch.einsum("vbmd,vbnd->vbmn", self.query(tokens), embeddings)
        score = score / math.sqrt(embeddings.size(-1))
        weights = score.mean(dim=2)
        return weights.mean(dim=-1)


class MAP(nn.Module):
    def __init__(self):
        super().__init__()
        self.extractor = VisualExtractor()
        self.decomposer = Decomposer()
        self.sampler = MultiheadSampler()

    def forward(self, embeddings, cls):
        visual = self.extractor(embeddings)
        tokens = self.decomposer(cls)
        weights = self.sampler(tokens, embeddings)
        return (visual * weights[..., None, None]).sum(dim=0)


class MIAVLM(nn.Module):
    def __init__(self, encoder, llm, dim=config.DIM):
        super().__init__()
        self.encoder = encoder
        self.llm = llm
        self.map = MAP()
        self.project = nn.Linear(dim, llm.config.d_model)

    def forward(self, views, input_ids, labels=None):
        embeddings = self.encoder(views)
        visual = self.project(self.map(embeddings, embeddings[:, :, 0]))
        text = self.llm.get_input_embeddings()(input_ids)
        inputs = torch.cat([visual, text], dim=1)

        if labels is not None:
            ignore = torch.full(visual.shape[:2], -100, dtype=labels.dtype, device=labels.device)
            labels = torch.cat([ignore, labels], dim=1)
        return self.llm(inputs_embeds=inputs, labels=labels)

    @torch.no_grad()
    def generate(self, views, input_ids, **kwargs):
        embeddings = self.encoder(views)
        visual = self.project(self.map(embeddings, embeddings[:, :, 0]))
        text = self.llm.get_input_embeddings()(input_ids)
        return self.llm.generate(inputs_embeds=torch.cat([visual, text], dim=1), **kwargs)
