# MIAVLM 主实验代码

```
miavlm/
  config.py     维度、视角数、训练与解码参数
  data.py       属性描述转正/负问题、9:1 划分、读写
  multiview.py  单图生成 3D 后按相机参数渲染多视角
  model.py      Visual Extractor、Multihead Sampler、MAP、MIAVLM
  train.py      语言建模损失训练循环
  eval.py       正/负准确率、HoOA 指标、顺序敏感性、推理时间
configs/
  train.yaml / eval.yaml
```

流程：`build_benchmark` 造正负问题 → `split` 划分 → `MultiviewGenerator`
生成 9 个视角 → `MIAVLM` 前向 / `train` → `evaluate` 得到 positive、
negative 和 HoOA。

依赖：`torch`、`transformers`、`openai`。3D 生成与渲染通过外部接口传入。
